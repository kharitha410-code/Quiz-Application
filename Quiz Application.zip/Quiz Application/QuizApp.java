import java.util.Scanner;

public class QuizApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        String[] questions = {
            "What is the capital of India?",
            "Which language is used for Android development?",
            "What does JVM stand for?"
        };

        String[][] options = {
            {"A. Mumbai", "B. Delhi", "C. Chennai", "D. Kolkata"},
            {"A. Java", "B. Python", "C. PHP", "D. HTML"},
            {"A. Java Virtual Machine", "B. Java Variable Method",
             "C. Joint Virtual Machine", "D. Java Verified Method"}
        };

        char[] answers = {'B', 'A', 'A'};

        int score = 0;

        for(int i = 0; i < questions.length; i++) {

            System.out.println("\nQuestion " + (i + 1));
            System.out.println(questions[i]);

            for(String option : options[i]) {
                System.out.println(option);
            }

            System.out.print("Enter Answer (A/B/C/D): ");
            char userAnswer = Character.toUpperCase(sc.next().charAt(0));

            if(userAnswer == answers[i]) {
                System.out.println("Correct Answer!");
                score++;
            } else {
                System.out.println("Wrong Answer!");
            }
        }

        System.out.println("\nQuiz Finished");
        System.out.println("Score: " + score + "/" + questions.length);

        sc.close();
    }
}